<?php
session_start();

$user = $_SESSION['user'];

if($user){
	echo '{"login":true,"user": $user}';
}else{
	echo '{"login":false}';
}